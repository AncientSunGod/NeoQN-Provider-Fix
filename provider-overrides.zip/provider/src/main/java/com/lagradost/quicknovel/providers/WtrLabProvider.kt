package com.lagradost.quicknovel.providers

import android.webkit.CookieManager
import com.fasterxml.jackson.annotation.JsonProperty
import com.lagradost.quicknovel.ChapterData
import com.lagradost.quicknovel.ErrorLoadingException
import com.lagradost.quicknovel.HeadMainPageResponse
import com.lagradost.quicknovel.LoadResponse
import com.lagradost.quicknovel.MainAPI
import com.lagradost.quicknovel.SearchResponse
import com.lagradost.quicknovel.app
import com.lagradost.quicknovel.fixUrlNull
import com.lagradost.quicknovel.newChapterData
import com.lagradost.quicknovel.newSearchResponse
import com.lagradost.quicknovel.newStreamResponse
import com.lagradost.quicknovel.network.WebViewResolver
import com.lagradost.quicknovel.setStatus
import com.lagradost.quicknovel.util.AppUtils.parseJson
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlin.math.roundToInt

/**
 * NeoQN 2.2.0-compatible WTR-LAB provider.
 *
 * Important: this is intentionally adapted to NeoQN 2.2.0's WebViewResolver /
 * MainAPI surface. The newer upstream WtrLabProvider cannot be copied directly
 * because its WebViewResolver and review APIs differ from NeoQN 2.2.0.
 *
 * Cloudflare handling uses NeoQN's existing CloudflareKiller first. If a WTR-LAB
 * request still comes back as a challenge, we open the WTR page in the app's
 * WebViewResolver and wait for a cf_clearance cookie, then retry the request.
 */
class WtrLabProvider : MainAPI() {
    override val mainUrl = "https://wtr-lab.com"
    override val name = "WTR-LAB"
    override val lang = "en"
    override val iconId: Int? = null
    override val hasMainPage = true
    override val usesCloudFlareKiller = true
    override val hasReviews = false

    override val mainCategories = listOf(
        "All" to "all",
        "Ongoing" to "ongoing",
        "Completed" to "completed"
    )

    override val orderBys = listOf(
        "Date" to "date",
        "Name" to "name",
        "View" to "view",
        "Reader" to "reader",
        "Chapter" to "chapter"
    )

    override val tags = listOf(
        "All" to "",
        "Action" to "1",
        "Adult" to "2",
        "Adventure" to "3",
        "Anime" to "4",
        "Arts" to "5",
        "Comedy" to "6",
        "Drama" to "7",
        "Eastern" to "8",
        "Ecchi" to "ecchi",
        "Fan-fiction" to "9",
        "Fantasy" to "10",
        "Game" to "11",
        "Gender-bender" to "12",
        "Harem" to "13",
        "Historical" to "14",
        "Horror" to "15",
        "Isekai" to "16",
        "Josei" to "17",
        "Lgbt" to "18",
        "Magic" to "19",
        "Magical-realism" to "20",
        "Manhua" to "21",
        "Martial-arts" to "22",
        "Mature" to "23",
        "Mecha" to "24",
        "Military" to "25",
        "Modern-life" to "26",
        "Movies" to "27",
        "Mystery" to "28",
        "Other" to "29",
        "Psychological" to "30",
        "Realistic-fiction" to "31",
        "Reincarnation" to "32",
        "Romance" to "33",
        "School-life" to "34",
        "Sci-fi" to "35",
        "Seinen" to "36",
        "Shoujo" to "37",
        "Shoujo-ai" to "38",
        "Shounen" to "39",
        "Shounen-ai" to "40",
        "Slice-of-life" to "41",
        "Smut" to "42",
        "Sports" to "43",
        "Supernatural" to "44",
        "System" to "45",
        "Tragedy" to "46",
        "Urban" to "47",
        "Urban-life" to "48",
        "Video-games" to "49",
        "War" to "50",
        "Wuxia" to "51",
        "Xianxia" to "52",
        "Xuanhuan" to "53",
        "Yaoi" to "54",
        "Yuri" to "55"
    )

    private suspend fun waitForCloudflare(url: String) {
        WebViewResolver(
            interceptUrl = Regex("\\A\\z"),
            userAgent = null,
            useOkhttp = false
        ).resolveUsingWebView(
            url = url,
            showDialog = true
        ) {
            CookieManager.getInstance().getCookie(url)?.contains("cf_clearance=") == true
        }
    }

    private fun isCloudflareChallenge(text: String): Boolean {
        val body = text.lowercase()
        return body.contains("cf-turnstile") ||
            body.contains("cf-challenge-response") ||
            body.contains("/cdn-cgi/challenge-platform/") ||
            body.contains("challenges.cloudflare.com/turnstile") ||
            body.contains("requireturnstile")
    }

    private suspend fun getDocument(url: String) = try {
        var response = app.get(url)
        if (isCloudflareChallenge(response.text)) {
            waitForCloudflare(url)
            response = app.get(url)
        }
        response.document
    } catch (_: Exception) {
        waitForCloudflare(url)
        app.get(url).document
    }

    override suspend fun loadMainPage(
        page: Int,
        mainCategory: String?,
        orderBy: String?,
        tag: String?
    ): HeadMainPageResponse {
        val url = "$mainUrl/en/novel-list?page=$page&status=$mainCategory&orderBy=$orderBy&genre=$tag"
        val doc = getDocument(url)
        val items = doc.select(".series-list>div").mapNotNull { card ->
            val a = card.selectFirst("a") ?: return@mapNotNull null
            newSearchResponse(a.attr("title"), a.attr("href")) {
                posterUrl = fixUrlNull(card.selectFirst("a img")?.attr("src"))
            }
        }
        return HeadMainPageResponse(url, items)
    }

    override suspend fun search(query: String): List<SearchResponse> {
        val url = "$mainUrl/en/novel-finder?text=${query.replace(" ", "+")}"
        val doc = getDocument(url)
        return doc.select(".series-list>div").mapNotNull { card ->
            val a = card.selectFirst("a") ?: return@mapNotNull null
            newSearchResponse(a.attr("title"), a.attr("href")) {
                posterUrl = fixUrlNull(card.selectFirst("a img")?.attr("src"))
            }
        }
    }

    private suspend fun getChapterRange(
        url: String,
        chaptersJson: ResultJsonResponse.Root,
        start: Long,
        end: Long
    ): List<ChapterData> {
        val rawId = chaptersJson.props.pageProps.serie.serieData.rawId
        val chapterDataUrl = "$mainUrl/api/chapters/$rawId?start=$start&end=$end"
        val chaptersDataJson = try {
            var response = app.get(chapterDataUrl)
            if (isCloudflareChallenge(response.text)) {
                waitForCloudflare(url)
                response = app.get(chapterDataUrl)
            }
            response.text
        } catch (_: Exception) {
            waitForCloudflare(url)
            app.get(chapterDataUrl).text
        }
        val chaptersData = parseJson<ResultChaptersJsonResponse.Root>(chaptersDataJson)
        return chaptersData.chapters.map { chapter ->
            newChapterData(
                "#${chapter.order} ${chapter.title}",
                "${url.trimEnd('/')}/chapter-${chapter.order}"
            ) {
                dateOfRelease = chapter.updatedAt
            }
        }
    }

    override suspend fun load(url: String): LoadResponse {
        val doc = getDocument(url)
        val title = doc.selectFirst("h1")?.text() ?: throw ErrorLoadingException("No title")
        val json = doc.selectFirst("#__NEXT_DATA__")?.data()
            ?: throw ErrorLoadingException("No WTR-LAB page data")
        val parsed = parseJson<ResultJsonResponse.Root>(json)
        val chapters = getChapterRange(
            url,
            parsed,
            1,
            parsed.props.pageProps.serie.serieData.rawChapterCount
        )

        return newStreamResponse(title, url, chapters) {
            synopsis = doc.selectFirst(".desc-wrap")?.text()
            posterUrl = fixUrlNull(doc.selectFirst(".image-wrap > img")?.attr("src"))
            doc.select("div.detail-buttons div").forEach { div ->
                if (div.text().contains("Views")) {
                    val text = div.ownText().split(" ")
                    this.views = text.getOrNull(2)?.trim()?.toIntOrNull()
                    setStatus(text.getOrNull(0)?.trim())
                }
            }
            val ratingText = doc.selectFirst("div.detail-buttons div.rating")?.text()
            peopleVoted = ratingText?.let { Regex("\\((\\d+)").find(it)?.groupValues?.getOrNull(1)?.toIntOrNull() }
            rating = ratingText?.let { text ->
                Regex("([\\d.]+)").find(text)?.groupValues?.getOrNull(1)?.toFloatOrNull()?.let {
                    (it * 20f * 10f).roundToInt()
                }
            }
        }
    }

    override suspend fun loadHtml(url: String): String? {
        val urlWithService = if (url.contains("?")) "$url&service=web" else "$url?service=web"

        return try {
            val doc = getDocument(urlWithService)
            val chapterJson = doc.selectFirst("#__NEXT_DATA__")?.data()
                ?: throw ErrorLoadingException("No WTR-LAB chapter JSON")
            val chapter = parseJson<LoadJsonResponse.Root>(chapterJson).props.pageProps.serie

            var bodyResponse = try {
                app.post(
                    url = "$mainUrl/api/reader/get",
                    data = mapOf(
                        "chapter_id" to chapter.chapter.id.toString(),
                        "chapter_no" to chapter.serieData.slug,
                        "force_retry" to "false",
                        "language" to "en",
                        "raw_id" to chapter.serieData.rawId.toString(),
                        "retry" to "false",
                        "translate" to "web",
                    )
                )
            } catch (_: Exception) {
                waitForCloudflare(urlWithService)
                app.post(
                    url = "$mainUrl/api/reader/get",
                    data = mapOf(
                        "chapter_id" to chapter.chapter.id.toString(),
                        "chapter_no" to chapter.serieData.slug,
                        "force_retry" to "false",
                        "language" to "en",
                        "raw_id" to chapter.serieData.rawId.toString(),
                        "retry" to "false",
                        "translate" to "web",
                    )
                )
            }
            if (isCloudflareChallenge(bodyResponse.text)) {
                waitForCloudflare(urlWithService)
                bodyResponse = app.post(
                    url = "$mainUrl/api/reader/get",
                    data = mapOf(
                        "chapter_id" to chapter.chapter.id.toString(),
                        "chapter_no" to chapter.serieData.slug,
                        "force_retry" to "false",
                        "language" to "en",
                        "raw_id" to chapter.serieData.rawId.toString(),
                        "retry" to "false",
                        "translate" to "web",
                    )
                )
            }

            val paragraphs = decryptContent(bodyResponse.parsed<LoadJsonResponse2.Root>().data.data.body)
            buildString {
                for (paragraph in paragraphs) append("<p>").append(paragraph).append("</p>")
            }
        } catch (e: Exception) {
            throw ErrorLoadingException("WTR-LAB chapter request failed: ${e.message}")
        }
    }

    private fun decryptContent(encryptedText: String): List<String> {
        if (encryptedText.isEmpty()) return emptyList()

        var isArray = false
        var rawText = encryptedText
        if (rawText.startsWith("arr:")) {
            isArray = true
            rawText = rawText.removePrefix("arr:")
        } else if (rawText.startsWith("str:")) {
            rawText = rawText.removePrefix("str:")
        }

        val parts = rawText.split(":")
        if (parts.size != 3) throw IllegalArgumentException("Invalid WTR-LAB encrypted content")

        val ivBytes = android.util.Base64.decode(parts[0], android.util.Base64.DEFAULT)
        val shortCipher = android.util.Base64.decode(parts[1], android.util.Base64.DEFAULT)
        val longCipher = android.util.Base64.decode(parts[2], android.util.Base64.DEFAULT)
        val cipherBytes = ByteArray(longCipher.size + shortCipher.size)
        System.arraycopy(longCipher, 0, cipherBytes, 0, longCipher.size)
        System.arraycopy(shortCipher, 0, cipherBytes, longCipher.size, shortCipher.size)

        val keyString = "IJAFUUxjM25hyzL2AZrn0wl7cESED6Ru"
        val keyBytes = keyString.substring(0, 32).toByteArray(Charsets.UTF_8)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(
            Cipher.DECRYPT_MODE,
            SecretKeySpec(keyBytes, "AES"),
            GCMParameterSpec(128, ivBytes)
        )

        val decryptedText = cipher.doFinal(cipherBytes).toString(Charsets.UTF_8)
        return if (isArray) parseJson<List<String>>(decryptedText) else listOf(decryptedText)
    }

    data class ResultChaptersJsonResponse(
        val chapters: List<Chapter>
    ) {
        data class Chapter(
            @JsonProperty("serie_id") val serieId: Long,
            val id: Long,
            val order: Long,
            val title: String,
            val name: String,
            @JsonProperty("updated_at") val updatedAt: String,
        )
    }

    object ResultJsonResponse {
        data class Root(val props: Props)
        data class Props(val pageProps: PageProps)
        data class PageProps(val serie: Serie)
        data class Serie(@JsonProperty("serie_data") val serieData: SerieData)
        data class SerieData(
            @JsonProperty("raw_id") val rawId: Long,
            @JsonProperty("id") val id: Long,
            @JsonProperty("raw_chapter_count") val rawChapterCount: Long,
        )
    }

    object LoadJsonResponse {
        data class Root(val props: Props)
        data class Props(val pageProps: PageProps)
        data class PageProps(val serie: Serie)
        data class Serie(
            @JsonProperty("serie_data") val serieData: SerieData,
            val chapter: Chapter,
        )
        data class Chapter(
            val id: Long,
            @JsonProperty("raw_id") val rawId: Long,
        )
        data class SerieData(
            val id: Long,
            val slug: String,
            @JsonProperty("raw_id") val rawId: Long,
        )
    }

    object LoadJsonResponse2 {
        data class Root(val data: Data)
        data class Data(val data: Data2)
        data class Data2(val body: String = "")
    }
}
