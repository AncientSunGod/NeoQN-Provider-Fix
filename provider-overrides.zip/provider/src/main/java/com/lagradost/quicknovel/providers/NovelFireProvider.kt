package com.lagradost.quicknovel.providers

import android.net.Uri
import com.fasterxml.jackson.annotation.JsonProperty
import com.lagradost.quicknovel.ChapterData
import com.lagradost.quicknovel.ErrorLoadingException
import com.lagradost.quicknovel.HeadMainPageResponse
import com.lagradost.quicknovel.LoadResponse
import com.lagradost.quicknovel.MainAPI
import com.lagradost.quicknovel.app
import com.lagradost.quicknovel.SearchResponse
import com.lagradost.quicknovel.fixUrl
import com.lagradost.quicknovel.fixUrlNull
import com.lagradost.quicknovel.newChapterData
import com.lagradost.quicknovel.newSearchResponse
import com.lagradost.quicknovel.newStreamResponse
import com.lagradost.quicknovel.setStatus

open class NovelFireProvider : MainAPI() {
    override val name = "NovelFire"
    override val mainUrl = "https://novelfire.net"
    override val hasMainPage = true
    override val hasReviews = false
    open val sectionUrl = "book"
    override val mainCategories = listOf("All" to "status-all", "Completed" to "status-completed", "Ongoing" to "status-ongoing")
    override val orderBys = listOf("Popular" to "sort-popular", "New" to "sort-new", "Updates" to "sort-latest-release")
    override val tags = listOf("All" to "all", "Action" to "action", "Adventure" to "adventure", "Comedy" to "comedy", "Drama" to "drama", "Fantasy" to "fantasy", "Harem" to "harem", "Historical" to "historical", "Horror" to "horror", "Isekai" to "isekai", "Romance" to "romance", "Sci-fi" to "sci-fi", "Shounen" to "shounen", "Supernatural" to "supernatural", "Wuxia" to "wuxia", "Xianxia" to "xianxia", "Xuanhuan" to "xuanhuan", "Yaoi" to "yaoi", "Yuri" to "yuri")

    override suspend fun loadMainPage(page: Int, mainCategory: String?, orderBy: String?, tag: String?): HeadMainPageResponse {
        val url = "$mainUrl/genre-${tag ?: "all"}/${orderBy ?: "sort-latest-release"}/${mainCategory ?: "status-all"}/all-novel?page=$page"
        val document = app.get(url).document
        val list = document.select("li.novel-item").mapNotNull { item ->
            val node = item.selectFirst("a[title]") ?: return@mapNotNull null
            newSearchResponse(node.attr("title").ifBlank { node.selectFirst("h4.novel-title")?.text() ?: return@mapNotNull null }, node.attr("href")) {
                posterUrl = fixUrlNull(item.selectFirst("img")?.attr("data-src") ?: item.selectFirst("img")?.attr("src"))
            }
        }
        return HeadMainPageResponse(url, list)
    }

    override suspend fun load(url: String): LoadResponse {
        val document = app.get(url).document
        val info = document.select("div.novel-info")
        val title = info.select("h1.novel-title").firstOrNull()?.text() ?: throw ErrorLoadingException("Title not found")
        val id = document.selectFirst("a#novel-report")?.attr("report-post_id")
        val chapters = getChapters(url, id)
        return newStreamResponse(title, fixUrl(url), chapters) {
            author = info.select("div.author > a").firstOrNull()?.text()
            posterUrl = fixUrlNull(document.selectFirst("figure.cover img")?.attr("src"))
            synopsis = document.selectFirst("meta[itemprop=description]")?.attr("content") ?: ""
            tags = info.select("div.categories ul li").map { it.text().trim() }.filter { it.isNotEmpty() }
            info.select("div.header-stats span").firstOrNull { it.text().contains("Status", true) }?.let { setStatus(it.selectFirst("strong")?.text()) }
        }
    }

    private suspend fun getChapters(url: String, id: String?): List<ChapterData> {
        val bookSlug = url.trimEnd('/').substringAfterLast('/')
        // Primary: current DataTables endpoint.
        if (!id.isNullOrBlank()) {
            try {
                val response = app.get("$mainUrl/ajax/listChapterDataAjax", params = mapOf(
                    "draw" to "1", "start" to "0", "length" to "-1",
                    "order[0][column]" to "0", "order[0][dir]" to "asc",
                    "post_id" to id, "only_bookmark" to "false", "search[value]" to "", "search[regex]" to "false"
                )).parsed<AjaxChapterRoot>()
                val chapters = response.data.orEmpty().mapNotNull { item ->
                    val n = item.nSort ?: return@mapNotNull null
                    newChapterData(item.title ?: "Chapter $n", "$mainUrl/$sectionUrl/$bookSlug/chapter-$n") {
                        dateOfRelease = item.createdAt
                    }
                }
                if (chapters.isNotEmpty()) return chapters
            } catch (_: Exception) { }
        }
        // Fallback: scrape the novel page. This prevents the provider from reporting 0 chapters
        // when the AJAX endpoint is blocked/rate-limited or its DataTables response changes.
        return try {
            val doc = app.get(url).document
            val seen = linkedMapOf<String, ChapterData>()
            doc.select("a[href*=/chapter-], a[href*='/$sectionUrl/']").forEach { a ->
                val href = a.attr("href")
                val match = Regex("/chapter-(\\d+)").find(href) ?: return@forEach
                val n = match.groupValues[1]
                seen[n] = newChapterData(a.text().trim().ifBlank { "Chapter $n" }, fixUrl(href), fix = false)
            }
            seen.values.sortedBy { Regex("\\d+").find(it.name)?.value?.toLongOrNull() ?: Long.MAX_VALUE }
        } catch (_: Exception) { emptyList() }
    }

    override suspend fun loadHtml(url: String): String? {
        val document = app.get(url).document
        val title = document.selectFirst("span.chapter-title")?.text().orEmpty()
        val content = document.selectFirst("div#content") ?: return null
        content.select("img[src*=disable-blocker.jpg]").remove()
        return if (title.isBlank()) content.html() else "<p>$title</p><br>${content.html()}"
    }

    override suspend fun search(query: String): List<SearchResponse> {
        val document = app.get("$mainUrl/search/?keyword=${Uri.encode(query.trim()).replace("%20", "+")}&page=1").document
        return document.select("ul.novel-list.horizontal.col2.chapters li.novel-item").mapNotNull { item ->
            val a = item.selectFirst("a") ?: return@mapNotNull null
            newSearchResponse(a.attr("title").trim(), a.attr("href")) {
                posterUrl = fixUrlNull(a.selectFirst("img")?.attr("src"))
            }
        }
    }

    data class AjaxChapterRoot(@JsonProperty("data") val data: List<AjaxChapterItem>? = null)
    data class AjaxChapterItem(@JsonProperty("n_sort") val nSort: Int? = null, @JsonProperty("title") val title: String? = null, @JsonProperty("bookmark_created_at") val createdAt: String? = null)
}
