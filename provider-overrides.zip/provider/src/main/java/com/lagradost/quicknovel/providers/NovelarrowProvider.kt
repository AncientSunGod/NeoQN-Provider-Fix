package com.lagradost.quicknovel.providers

import android.net.Uri
import com.fasterxml.jackson.annotation.JsonProperty
import com.lagradost.quicknovel.ChapterData
import com.lagradost.quicknovel.ErrorLoadingException
import com.lagradost.quicknovel.HeadMainPageResponse
import com.lagradost.quicknovel.LoadResponse
import com.lagradost.quicknovel.MainAPI
import com.lagradost.quicknovel.app
import com.lagradost.quicknovel.SearchResponse
import com.lagradost.quicknovel.fixUrlNull
import com.lagradost.quicknovel.newChapterData
import com.lagradost.quicknovel.newSearchResponse
import com.lagradost.quicknovel.newStreamResponse
import com.lagradost.quicknovel.setStatus

/** Updated NovelArrow implementation. The important fixes are the current
 * sort values: POPULAR = popular this week, empty = last updated, NEW = recently added. */
class NovelarrowProvider : MainAPI() {
    override val name = "NovelArrow"
    override val mainUrl = "https://novelarrow.com"
    override val hasMainPage = true
    override val usesCloudFlareKiller = true

    override val mainCategories = listOf(
        "Popular this week" to "POPULAR",
        "Last updated" to "",
        "Recently added" to "NEW",
        "Top (most viewed)" to "ALL_TIME",
        "Top rated" to "RATING",
        "Most chapters" to "CHAPTERS"
    )

    override suspend fun loadMainPage(page: Int, mainCategory: String?, orderBy: String?, tag: String?): HeadMainPageResponse {
        val sort = mainCategory ?: ""
        val genre = tag ?: "all"
        val url = "$mainUrl/genre/$genre?sort=$sort&page=$page"
        val document = app.get(url).document
        val list = document.select("article.site-panel.group.flex").mapNotNull { card ->
            val href = card.selectFirst("a")?.attr("href") ?: return@mapNotNull null
            val title = card.selectFirst("h2")?.text() ?: return@mapNotNull null
            newSearchResponse(title, href) {
                posterUrl = fixUrlNull(card.selectFirst("img")?.attr("src"))
            }
        }
        return HeadMainPageResponse(url, list)
    }

    private suspend fun getChapters(slug: String): List<ChapterData> {
        val response = app.get("$mainUrl/api-web/novels/$slug/chapters?sort=asc")
        val chapters = try {
            response.parsed<ChaptersResponse>().items
        } catch (_: Exception) {
            response.parsed<ChaptersResponseNested>().items.flatten()
        }
        return chapters.mapNotNull { ch ->
            if (ch.premium || ch.platinum || ch.chapterId.isNullOrBlank()) return@mapNotNull null
            newChapterData(ch.chapterName, "$mainUrl/api-web/novels/$slug/chapters/${ch.chapterId}")
        }
    }

    override suspend fun load(url: String): LoadResponse {
        val realUrl = url.replace("https://novelbin.com/b/", "$mainUrl/novel/")
        val document = app.get(realUrl).document
        val title = document.selectFirst("title")?.text() ?: throw ErrorLoadingException("No title")
        val slug = realUrl.substringAfter("/novel/").trimEnd('/')
        val chapters = getChapters(slug)
        return newStreamResponse(title, realUrl, chapters) {
            posterUrl = document.selectFirst("meta[property=og:image]")?.attr("content")
            synopsis = document.selectFirst("meta[name=description]")?.attr("content")
            author = document.selectFirst("meta[name=author]")?.attr("content")
            setStatus(document.selectFirst("meta[name=og:novel:status]")?.attr("content"))
        }
    }

    override suspend fun loadHtml(url: String): String {
        val response = app.get(url).parsed<ChapterResponse>()
        return response.item?.chapterInfo?.chapterContent ?: throw ErrorLoadingException("No content")
    }

    override suspend fun search(query: String): List<SearchResponse> {
        val url = "$mainUrl/api-web/novels?limit=20&page=1&status=all&sort=SEARCH_KEYWORD&genre=ALL&keyword=${Uri.encode(query.trim()).replace("%20", "+")}"
        val data = app.get(url).parsed<MainPageResponse>()
        return data.items.map { item ->
            newSearchResponse(item.novelName, "$mainUrl/novel/${item.novelId}")
        }
    }

    data class MainPageResponse(@JsonProperty("items") val items: List<NovelInfo>)
    data class NovelInfo(@JsonProperty("novel_name") val novelName: String, @JsonProperty("novel_id") val novelId: String)
    data class ChaptersResponse(@JsonProperty("items") val items: List<ChapterInfo>)
    data class ChaptersResponseNested(@JsonProperty("items") val items: List<List<ChapterInfo>>)
    data class ChapterResponse(@JsonProperty("item") val item: ChapterItemWrapper?)
    data class ChapterItemWrapper(@JsonProperty("chapterInfo") val chapterInfo: ChapterInfo?)
    data class ChapterInfo(
        @JsonProperty("chapter_id") val chapterId: String?,
        @JsonProperty("chapter_name") val chapterName: String,
        @JsonProperty("platinum_content") val platinum: Boolean = false,
        @JsonProperty("premium_content") val premium: Boolean = false,
        @JsonProperty("chapter_content") val chapterContent: String? = null
    )
}
