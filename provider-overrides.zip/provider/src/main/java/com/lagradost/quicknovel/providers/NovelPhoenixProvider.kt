package com.lagradost.quicknovel.providers

/** NovelPhoenix uses the same site family/layout as NovelFire, but its novel path
 * segment is /novel/ rather than /book/. */
class NovelPhoenixProvider : NovelFireProvider() {
    override val name = "Novel Phoenix"
    override val mainUrl = "https://novelphoenix.com"
    override val sectionUrl = "novel"
}
